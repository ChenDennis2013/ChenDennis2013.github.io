from you_get.common import main
from pymsgbox import prompt as pr
import sys
import os
a = open("sfp.db").read()
sys.argv = ["you-get",pr("请输入网址","全网视/音频/图片下载器"),"-o",a,"--debug"]
main()