from tkinter.filedialog import askdirectory as dir
sfp = open("sfp.db")
a = dir(title="请选择文件保存路径(若选择的是空/取消请重新设置)",initialdir=sfp.read())
sfp = open("sfp.db","w")
sfp.write(a)
